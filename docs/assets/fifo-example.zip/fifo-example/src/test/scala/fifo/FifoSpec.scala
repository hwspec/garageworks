// See README.md for license details.
package fifo

import chisel3._
import chisel3.simulator.scalatest.ChiselSim
import org.scalatest.freespec.AnyFreeSpec

class FifoSpec extends AnyFreeSpec with ChiselSim {
  "Fifo should write, read, and report empty/full correctly" in {
    simulate(new Fifo(bw = 32, depth = 16)) { dut =>
      dut.reset.poke(true.B)
      dut.clock.step()
      dut.reset.poke(false.B)
      dut.clock.step()
      assert(dut.io.empty.peek().litToBoolean)
      assert(!dut.io.full.peek().litToBoolean)

      // write one word, then read it back
      dut.io.wrEn.poke(true.B)
      dut.io.wrData.poke(0x1234.U)
      dut.clock.step()
      dut.io.wrEn.poke(false.B)
      assert(!dut.io.empty.peek().litToBoolean)

      dut.io.rdEn.poke(true.B)
      dut.clock.step()
      dut.io.rdEn.poke(false.B)
      dut.io.rdData.expect(0x1234.U)
      assert(dut.io.empty.peek().litToBoolean)

      // fill the FIFO completely and check full
      dut.io.wrEn.poke(true.B)
      for (i <- 0 until 16) {
        dut.io.wrData.poke(i.U)
        dut.clock.step()
      }
      dut.io.wrEn.poke(false.B)
      assert(dut.io.full.peek().litToBoolean)

      // drain it back out, in write order
      dut.io.rdEn.poke(true.B)
      for (i <- 0 until 16) {
        dut.clock.step()
        dut.io.rdData.expect(i.U)
      }
      dut.io.rdEn.poke(false.B)
      assert(dut.io.empty.peek().litToBoolean)

      // soft reset: rdData must read back as zero
      dut.reset.poke(true.B)
      dut.clock.step()
      dut.reset.poke(false.B)
      dut.io.rdData.expect(0.U)
      assert(dut.io.empty.peek().litToBoolean)
    }
  }
}
