// See README.md for license details.
package fifo

import chisel3._
import chisel3.util.Queue

/** Simple synchronous FIFO: `bw`-bit words, `depth` entries, built on chisel3.util.Queue. */
class Fifo(val bw: Int = 32, val depth: Int = 16) extends Module {
  val io = IO(new Bundle {
    val wrEn   = Input(Bool())
    val wrData = Input(UInt(bw.W))
    val rdEn   = Input(Bool())
    val rdData = Output(UInt(bw.W))
    val empty  = Output(Bool())
    val full   = Output(Bool())
  })

  val q = Module(new Queue(UInt(bw.W), depth))
  q.io.enq.valid := io.wrEn
  q.io.enq.bits  := io.wrData
  q.io.deq.ready := io.rdEn

  io.full  := !q.io.enq.ready
  io.empty := !q.io.deq.valid

  val rdDataReg = RegInit(0.U(bw.W))
  when(io.rdEn && q.io.deq.valid) {
    rdDataReg := q.io.deq.bits
  }
  io.rdData := rdDataReg
}
